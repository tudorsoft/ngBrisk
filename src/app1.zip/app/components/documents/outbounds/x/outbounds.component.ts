import { Component } from '@angular/core';

@Component({
  selector: 'app-outbounds',
  templateUrl: './outbounds.component.html',
  styleUrls: ['./outbounds.component.css']
})
export class OutboundsComponent {
  // Logica pentru gestionarea ieșirilor va fi implementată aici
}
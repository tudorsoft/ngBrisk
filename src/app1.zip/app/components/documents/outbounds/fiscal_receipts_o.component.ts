import { Component } from '@angular/core';

@Component({
  selector: 'app-fiscal-receipts-o',
  templateUrl: './fiscal_receipts_o.component.html',
  styleUrls: ['./fiscal_receipts_o.component.css']
})
export class FiscalReceiptsOComponent {
  // Logica pentru gestionarea bonurilor fiscale va fi implementată aici
}
import { Component } from '@angular/core';

@Component({
  selector: 'app-invoices-o',
  templateUrl: './invoices_o.component.html',
  styleUrls: ['./invoices_o.component.css']
})
export class InvoicesOComponent {
  // Logica pentru gestionarea facturilor clienți va fi implementată aici
}
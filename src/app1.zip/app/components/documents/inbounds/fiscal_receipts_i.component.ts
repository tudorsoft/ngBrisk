import { Component } from '@angular/core';

@Component({
  selector: 'app-fiscal-receipts-i',
  templateUrl: './fiscal_receipts_i.component.html',
  styleUrls: ['./fiscal_receipts_i.component.css']
})
export class FiscalReceiptsIComponent {
  // Logica pentru gestionarea bonurilor fiscale va fi implementată aici
}
//data-table.component.ts:
//-----------------------
import { Component, Input, OnInit, AfterViewChecked, Output, EventEmitter, ChangeDetectorRef, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-data-table',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent implements OnInit {
    @Input() title: string = '';
    private _filteredData: any[] = []; // Variabilă privată pentru datele filtrate
    @Input() set filteredData(data: any[]) {
      this._filteredData = data; // Salvează datele filtrate
      this.originalData = data; // Salvează datele originale
      this.filterData(); // Aplică filtrul imediat
    }
    get filteredData(): any[] {
      return this._filteredData; // Returnează datele filtrate
    }
    @Input() columns: { label: string; name: string; type: string; showTotal?: boolean; decimals?: number; width?: string; }[] = [];
    @Input() columnLabels: string[] = [];
    @Input() recordCount: number = 0;
    @Output() refresh = new EventEmitter<void>();
  
    searchValues: string[] = [];
    selectedColumns: string[] = [];
    originalData: any[] = []; // Copie a datelor originale
  
    
    constructor(private cd: ChangeDetectorRef) {}

    // Adăugăm variabilele pentru sortare
    sortColumn: string = ''; 
    sortDirection: 'asc' | 'desc' = 'asc'; 
    
    ngOnInit() {
        this.searchValues = Array(this.columns.length).fill('');
        this.selectedColumns = this.columns.map(col => col.name);
    }
  
    ngOnChanges(changes: SimpleChanges) {
        if ('filteredData' in changes) {
          this.filterData(); // Ensure data is filtered whenever it changes
        }
      }
    
    toggleColumn(column: string) {
      const index = this.selectedColumns.indexOf(column);
      if (index > -1) {
        this.selectedColumns.splice(index, 1);
      } else {
        this.selectedColumns.push(column);
      }
      this.filterData();
    }

    getSearchValue(columnName: string): string {
        const index = this.columns.findIndex(c => c.name === columnName);
        return index !== -1 ? this.searchValues[index] : ''; // Safely access search values
    }
    
    // Optional: Method to set the search value based on the column name
    setSearchValue(columnName: string, value: string) {
        const index = this.columns.findIndex(c => c.name === columnName);
        if (index !== -1) {
            this.searchValues[index] = value; // Update the corresponding search value
        }
    }

    filterData() {
        if (!this.originalData) return; // Verifică dacă există date originale
    
        // Filtrează datele pe baza valorilor din searchValues
        this._filteredData = this.originalData.filter(item => {
          return this.columns.every((column, index) => {
            const searchValue = this.searchValues[index]?.toLowerCase() ?? ''; // Safe access
            return item[column.name]?.toString().toLowerCase().includes(searchValue) || !this.selectedColumns.includes(column.name);
          });
        });
    
        this.applySorting(); // Aplică sortarea după filtrare
        this.cd.detectChanges(); // Forțează detectarea schimbărilor
    }

    applySorting() {
        if (this.sortColumn) {
            this.filteredData.sort((a, b) => {
                const aValue = a[this.sortColumn];
                const bValue = b[this.sortColumn];
    
                if (aValue < bValue) return this.sortDirection === 'asc' ? -1 : 1;
                if (aValue > bValue) return this.sortDirection === 'asc' ? 1 : -1;
                return 0;
            });
        }
    }

    sortData(columnName: string) {
        if (this.sortColumn === columnName) {
          this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc'; // Inversăm direcția
        } else {
          this.sortColumn = columnName;
          this.sortDirection = 'asc';
        }
        this.filterData();
    }

    isNumericColumn(column: string): boolean {
        const col = this.columns.find(c => c.name === column);
        return col ? col.type === 'numeric' : false;
    }

    formatNumber(value: any, columnName: string): string {
        const decimals = this.columns.find(c => c.name === columnName)?.decimals || 0;
        return typeof value === 'number' ? value.toFixed(decimals) : '';
    }

    calculateTotal(column: string): string {
        const decimalPlaces = this.columns.find(c => c.name === column)?.decimals || 0;
        const total = this.filteredData.reduce((acc, item) => {
            const value = item[column];
            return typeof value === 'number' ? acc + value : acc;
        }, 0);
        return total.toFixed(decimalPlaces);
    }

    showTotals(): boolean {
        return this.filteredData.length > 0;
    }

    canShowTotal(column: string): boolean {
        const col = this.columns.find(c => c.name === column);
        return col ? col.showTotal === true : false; // Check if the column allows total display
    }
    
    getColumnWidth(columnName: string): string {
        const col = this.columns.find(c => c.name === columnName);
        return col ? col.width || 'auto' : 'auto'; // Return the width or 'auto' as default
    }

    onRefresh() {
        this.refresh.emit();
        this.filterData();
    }

}
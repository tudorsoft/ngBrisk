//pv.component.ts:
//----------------------
import { HttpClientModule  } from '@angular/common/http';
import { HttpClient        } from '@angular/common/http';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { CommonModule      } from '@angular/common';
import { StorageService    } from '../../../services/storage.service';
import { ErrorService      } from '../../../services/error.service';
import { DataTableComponent} from '../../data-table.component';

interface ColumnDefinition {
  label: string;
  name: string;
  type: string;
  showTotal?: boolean;
  decimals?: number;
  width?: string;
}

@Component({
  selector: 'app-pv',
  standalone: true,
  imports: [CommonModule, HttpClientModule, DataTableComponent],
  templateUrl: './pv.component.html',
  styleUrls: ['./pv.component.scss'],
})
export class PvComponent implements OnInit {
  @Output() dataUpdated = new EventEmitter<any[]>();
  filteredData: any[] = [];
  errorMessage: string | null = null;
  recordCount: number = 0; 

  columns: ColumnDefinition[] = [
    //{ label: 'ID', name: 'id', type: 'numeric', width: '70px' },
    { label: 'Data', name: 'data_doc', type: 'date' },
    { label: 'Numar', name: 'numar', type: 'text' },
    { label: 'Client', name: 'den_firma', type: 'text' },
    { label: 'P.Lucru', name: 'den_plfrm', type: 'text' },
    { label: 'Categ.', name: 'den_comcat', type: 'text' },
    //{ label: 'Denumire Furnizor', name: 'supplierName', type: 'text' },
    //{ label: 'Valoare', name: 'amount', type: 'numeric', showTotal: true, decimals: 2 },
  ];

  selectedColumns: string[] = this.columns.map(col => col.name );
  columnLabels   : string[] = this.columns.map(col => col.label);

  constructor( public storageService: StorageService, 
               private errorService: ErrorService,
               private http: HttpClient ) {}
  ngOnInit() {
    this.fetchData();
  }
  
  fetchData() {
    const apiUrl = (this.storageService.cDatabaseUrl.endsWith('/') ? this.storageService.cDatabaseUrl.slice(0, -1) : this.storageService.cDatabaseUrl);
    console.log('fetchData a fost apelat');
    if (apiUrl !== '') {
      const fullUrl = apiUrl + '/wngPv';
      this.http.get<any[]>(fullUrl).subscribe({
        next: (response) => {
          this.filteredData = [...response];
          this.recordCount = this.filteredData.length; 
          this.errorMessage = null;
          console.log('Datele au fost preluate:', this.filteredData);
          this.dataUpdated.emit(this.filteredData);
        },
        error: (error) => {
          console.error('Eroare accesare ' + fullUrl, error);
          this.errorMessage = this.errorService.getErrorMessage(error);
          this.filteredData = [];
          this.recordCount = 0;
        },
      });
    }
  }

}
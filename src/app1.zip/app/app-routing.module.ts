//app-routing.module.ts:
//---------------------
import { NgModule } from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';
@NgModule({
  imports: [RouterModule.forRoot([])],
  exports: [RouterModule]
})
export class AppRoutingModule {

}